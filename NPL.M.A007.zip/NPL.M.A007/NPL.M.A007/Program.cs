﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace NPL.M.A007
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            MainMenu();

        }
        /// <summary>
        /// Main menu
        /// </summary>
        private static void MainMenu()
        {
            int selectMenu = 0;
            List<SalariedEmployee> salariedEmployees = new List<SalariedEmployee>();
            List<HourlyEmployee> hourlyEmployees = new List<HourlyEmployee>();

            double wage = 0.00;
            double workingHours = 0.00;
            double commissionRate = 0.00;
            double grossSales = 0.00;
            double basicSalary = 0.00;

            while (selectMenu != 4)
            {
                Console.WriteLine("Please select the admin area you require: ");
                Console.WriteLine("1. Import Employee. ");
                Console.WriteLine("2. Display Employee. ");
                Console.WriteLine("3. Search Employee. ");
                Console.WriteLine("4. Exit. ");
                selectMenu = int.Parse(Console.ReadLine());

                Console.WriteLine("");
                Console.Write($"Enter Menu Option Number: {selectMenu}");
                Console.WriteLine("");

                switch (selectMenu)
                {
                    case 1:
                        ImportEmployee(salariedEmployees, hourlyEmployees, ref wage, ref workingHours, ref commissionRate, ref grossSales, ref basicSalary);

                        break;

                    case 2:
                        DisplayAllEmployee(salariedEmployees, hourlyEmployees);
                        break;

                    case 3:
                        MenuSearch(salariedEmployees, hourlyEmployees);
                        break;

                    case 4:
                        Console.WriteLine("\tExit!!!");
                        Console.ReadKey();

                        break;
                }
            }
        }

        /// <summary>
        /// Import Employee
        /// </summary>
        /// <param name="salariedEmployees"></param>
        /// <param name="hourlyEmployees"></param>
        /// <param name="wage"></param>
        /// <param name="workingHours"></param>
        /// <param name="commissionRate"></param>
        /// <param name="grossSales"></param>
        /// <param name="basicSalary"></param>
        private static void ImportEmployee(List<SalariedEmployee> salariedEmployees, List<HourlyEmployee> hourlyEmployees, ref double wage, ref double workingHours, ref double commissionRate, ref double grossSales, ref double basicSalary)
        {
            int selectImportEmployee = 0;

            while (selectImportEmployee != 3)
            {
                Console.WriteLine("======== Import Employee ========");
                Console.WriteLine("1. Salaried Employee.");
                Console.WriteLine("2. Hourly Employee");
                Console.WriteLine("3. Main menu");

                selectImportEmployee = int.Parse(Console.ReadLine());

                Console.WriteLine("");
                Console.Write($"Enter Menu Option Number: {selectImportEmployee}");
                Console.WriteLine("");

                switch (selectImportEmployee)
                {
                    case 1:
                        InputEmployeeSalaried(salariedEmployees, ref commissionRate, ref grossSales, ref basicSalary, selectImportEmployee);

                        break;

                    case 2:

                        InputEmployeeWorkHour(hourlyEmployees, ref wage, ref workingHours, selectImportEmployee);

                        break;

                    case 3:
                        Console.WriteLine("\tThoat");
                        break;

                    default:
                        break;
                }
            }
        }

        /// <summary>
        /// Display All Employee
        /// </summary>
        /// <param name="salariedEmployees"></param>
        /// <param name="hourlyEmployees"></param>
        private static void DisplayAllEmployee(List<SalariedEmployee> salariedEmployees, List<HourlyEmployee> hourlyEmployees)
        {
            Console.WriteLine("--------Display");
            Console.WriteLine("========SalariedEmployee");

            foreach (var item in salariedEmployees)
            {
                Console.WriteLine("\t" + item.ToString());
            }

            Console.WriteLine("========WorkingHourEmployee");

            foreach (var item in hourlyEmployees)
            {
                Console.WriteLine("\t" + item.ToString());
            }
        }

        /// <summary>
        /// Menu Search
        /// </summary>
        /// <param name="salariedEmployees"></param>
        /// <param name="hourlyEmployees"></param>
        private static void MenuSearch(List<SalariedEmployee> salariedEmployees, List<HourlyEmployee> hourlyEmployees)
        {
            int selectSearchEmployee = 0;
            while (selectSearchEmployee != 3)
            {
                int selectMenuSearch;
                Console.WriteLine("======== Search Employee ========");
                Console.WriteLine("1. By Employee Type");
                Console.WriteLine("2. By Employee Name");
                Console.WriteLine("3. Main Menu");
                Console.Write("Enter Menu Option Number: ");
                selectMenuSearch = Convert.ToInt32(Console.ReadLine());

                switch (selectMenuSearch)
                {
                    case 1:
                        SearchType(salariedEmployees, hourlyEmployees);
                        break;
                    case 2:
                        SearchName(salariedEmployees, hourlyEmployees);
                        break;
                    case 3:
                        break;
                }
            }
        }

        /// <summary>
        /// Input Salaried Employee
        /// </summary>
        /// <param name="salariedEmployees"></param>
        /// <param name="commissionRate"></param>
        /// <param name="grossSales"></param>
        /// <param name="basicSalary"></param>
        /// <param name="selectImportEmployee"></param>
        private static void InputEmployeeSalaried(List<SalariedEmployee> salariedEmployees, ref double commissionRate, ref double grossSales, ref double basicSalary, int selectImportEmployee)
        {
            if (selectImportEmployee == 1)
            {
                Console.Write("\tInput Id: ");
                string sSNSaEm = Console.ReadLine();

                Console.Write("\tInput FirstName: ");
                string firstNameSaEm = Console.ReadLine();

                Console.Write("\tInput LastName: ");
                string lastNameSaEm = Console.ReadLine();

                string dateOfBirthSaEm = string.Empty;
                while (CheckedDate(dateOfBirthSaEm) != true)
                {
                    // tien hanh nhap email
                    Console.Write("\tInput Birthday: ");
                    dateOfBirthSaEm = Console.ReadLine();

                    // check email 
                    if (CheckedDate(dateOfBirthSaEm) != true)
                    {
                        Console.WriteLine("\tDate not invalid");
                    }

                }

                string phoneSaEm = string.Empty;
                while (CheckedPhone(phoneSaEm) != true)
                {
                    // tien hanh nhap phone
                    Console.Write("\tInput Phone: ");
                    phoneSaEm = Console.ReadLine();

                    // check email 
                    if (CheckedPhone(phoneSaEm) != true)
                    {
                        Console.WriteLine("\tPhone not invalid");
                    }

                }

                string emailSaEm = string.Empty;
                while (CheckedEmail(emailSaEm) != true)
                {
                    // tien hanh nhap email
                    Console.Write("\tInput email: ");
                    emailSaEm = Console.ReadLine();

                    // check email 
                    if (CheckedEmail(emailSaEm) != true)
                    {
                        Console.WriteLine("\tMail not invalid");
                    }

                }


                Console.Write("\tInput CommissionRate: ");
                commissionRate = Convert.ToDouble(Console.ReadLine());

                Console.Write("\tInput GrossSales: ");
                grossSales = Convert.ToDouble(Console.ReadLine());

                Console.Write("\tInput BasicSalary: ");
                basicSalary = Convert.ToDouble(Console.ReadLine());

                Employee _employeeSalaried = new SalariedEmployee(sSNSaEm, firstNameSaEm, lastNameSaEm, dateOfBirthSaEm, phoneSaEm, emailSaEm, commissionRate, grossSales, basicSalary);
                salariedEmployees.Add((SalariedEmployee)_employeeSalaried);
            }
        }

        /// <summary>
        /// Input Working Hour Employee
        /// </summary>
        /// <param name="hourlyEmployees"></param>
        /// <param name="wage"></param>
        /// <param name="workingHours"></param>
        /// <param name="selectImportEmployee"></param>
        private static void InputEmployeeWorkHour(List<HourlyEmployee> hourlyEmployees, ref double wage, ref double workingHours, int selectImportEmployee)
        {
            if (selectImportEmployee == 2)
            {
                Console.Write("\tInput Id: ");
                string sSNWorkHour = Console.ReadLine();

                Console.Write("\tInput FirstName: ");
                string firstNameWorkHour = Console.ReadLine();

                Console.Write("\tInput LastName: ");
                string lastNameWorkHour = Console.ReadLine();

                string dateBirthWorkHour = string.Empty;
                while (CheckedDate(dateBirthWorkHour) != true)
                {
                    // tien hanh nhap email
                    Console.Write("\tInput Birthday: ");
                    dateBirthWorkHour = Console.ReadLine();

                    // check email 
                    if (CheckedDate(dateBirthWorkHour) != true)
                    {
                        Console.WriteLine("\tDate not invalid");
                    }

                }

                string phoneWorkHour = string.Empty;
                while (CheckedPhone(phoneWorkHour) != true)
                {
                    // tien hanh nhap phone
                    Console.Write("\tInput Phone: ");
                    phoneWorkHour = Console.ReadLine();

                    // check email 
                    if (CheckedPhone(phoneWorkHour) != true)
                    {
                        Console.WriteLine("\tPhone not invalid");
                    }

                }

                string emailWorkHour = string.Empty;
                while (CheckedEmail(emailWorkHour) != true)
                {
                    // tien hanh nhap email
                    Console.Write("\tInput email: ");
                    emailWorkHour = Console.ReadLine();

                    // check email 
                    if (CheckedEmail(emailWorkHour) != true)
                    {
                        Console.WriteLine("\tEmail not invalid");
                    }

                }

                Console.Write("\tInput wage: ");
                wage = Convert.ToDouble(Console.ReadLine());

                Console.Write("\tInput working hours: ");
                workingHours = Convert.ToDouble(Console.ReadLine());

                Employee _employeeWorkingHour = new HourlyEmployee(sSNWorkHour, firstNameWorkHour, lastNameWorkHour, dateBirthWorkHour, phoneWorkHour, emailWorkHour, wage, workingHours);
                hourlyEmployees.Add((HourlyEmployee)_employeeWorkingHour);
            }
        }

        /// <summary>
        /// Search Type
        /// </summary>
        /// <param name="salariedEmployees"></param>
        /// <param name="hourlyEmployees"></param>
        private static void SearchType(List<SalariedEmployee> salariedEmployees, List<HourlyEmployee> hourlyEmployees)
        {
            Console.Write("Enter Employee Type: ");
            string searchType = Console.ReadLine();
            if (searchType == "Hourly")
            {
                Console.WriteLine("========WorkingHourEmployee");

                foreach (var item in hourlyEmployees)
                {
                    Console.WriteLine("\t" + item.ToString());
                }
            }

            if (searchType == "Salary")
            {
                Console.WriteLine("========SalariedEmployee");

                foreach (var item in salariedEmployees)
                {
                    Console.WriteLine("\t" + item.ToString());
                }
            }
        }

        /// <summary>
        /// Search Name
        /// </summary>
        /// <param name="salariedEmployees"></param>
        /// <param name="hourlyEmployees"></param>
        private static void SearchName(List<SalariedEmployee> salariedEmployees, List<HourlyEmployee> hourlyEmployees)
        {
            Console.Write("Enter Employee Name: ");
            string searchName = Console.ReadLine();

            foreach (var item in hourlyEmployees)
            {
                if ((item.FirstName + " " + item.LastName).Contains(searchName))
                {
                    Console.WriteLine("\t" + item.ToString());
                }
                else
                {
                    break;
                }
            }

            foreach (var item in salariedEmployees)
            {
                if ((item.FirstName + " " + item.LastName).Contains(searchName))
                {
                    Console.WriteLine("\t" + item.ToString());
                }
                else
                {
                    break;
                }
            }

            Console.WriteLine("Not Found!!!");
        }

        private static bool CheckedEmail(string email)
        {
            // Khai bao
            string characterEmail = @"[a-zA-Z0-9._]+@([a-z].)";

            // Call regex
            Regex regex = new Regex(characterEmail);


            // match regex
            Match match = regex.Match(email);

            // check
            if (match.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private static bool CheckedDate(string date)
        {
            // Khai bao
            string characterEmail = @"\d+\/\d+\/\d+";

            // Call regex
            Regex regex = new Regex(characterEmail);


            // match regex
            Match match = regex.Match(date);

            // check
            if (match.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private static bool CheckedPhone(string phone)
        {
            // Khai bao
            string characterPhone = @"[0-9]{7,}";

            // Call regex
            Regex regex = new Regex(characterPhone);


            // match regex
            Match match = regex.Match(phone);

            // check
            if (match.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
