﻿namespace NPL.M.A007
{
    public class HourlyEmployee : Employee
    {
        public HourlyEmployee()
        {

        }

        public HourlyEmployee(string sSN, string firstName, string lastName, string birthDate, string phone, string email, double wage, double workingHour)
            : base(sSN, firstName, lastName, birthDate, phone, email)
        {
           
            Wage = wage;

            WorkingHour = workingHour;
        }

        public double Wage { get; set; }

        public double WorkingHour { get; set; }

        public override string ToString()
        {
            return base.ToString() + string.Format("{0, 20}{1, 20}", Wage, WorkingHour);
        }
    }
}
