﻿using System.ComponentModel;

namespace NPL.M.A007
{
    public class Employee
    {
        public Employee()
        {

        }

        public Employee(string sSN, string firstName, string lastName)
        {
            SSN = sSN;
            FirstName = firstName;
            LastName = lastName;
        }

        public Employee(string sSN, string firstName, string lastName, string birthDate, string phone, string email)
        {
            SSN = sSN;
            FirstName = firstName;
            LastName = lastName;
            BirthDate = birthDate;
            Phone = phone;
            Email = email;
        }

        [DisplayName("EmployeeId")]
        public string SSN { get; set; }

        [DisplayName("FirstName")]
        public string FirstName { get; set; }

        [DisplayName("LastName")]
        public string LastName { get; set; }

        [DisplayName("Birthday")]
        public string BirthDate { get; set; }

        [DisplayName("Phone")]
        public string Phone { get; set; }

        [DisplayName("Email")]
        public string Email { get; set; }

        public override string ToString() {
            return string.Format("{0, 20}{1, 20}{2, 20}{3, 20}{4, 20}{5, 20}", SSN, FirstName, LastName, BirthDate, Phone, Email);
        }
    }
}
