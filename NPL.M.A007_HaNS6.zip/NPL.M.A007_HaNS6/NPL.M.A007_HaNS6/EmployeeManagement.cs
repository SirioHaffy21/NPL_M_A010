﻿using NPL.M.A007_HaNS6.Models;
using System.Collections.Generic;

namespace NPL.M.A007_HaNS6
{
    public class EmployeeManagement
    {
        public static List<Employee> Employees { get; set; } = new List<Employee>();
        public static List<SalariedEmployee> SalariedEmployees { get; set; } = new List<SalariedEmployee>();
        public static List<HourlyEmployee> HourlyEmployees { get; set; } = new List<HourlyEmployee>();

        public void Add(Employee employee)
        {
            Employees.Add(employee);
        }

        public void AddSalary(SalariedEmployee employee)
        {
            SalariedEmployees.Add(employee);
        }

        public void AddHourly(HourlyEmployee employee)
        {
            HourlyEmployees.Add(employee);
        }

        public void DisplayAll()
        {
            Employees.ForEach(x => System.Console.WriteLine(x.ToString() + " " + x.GetType()));
        }

        public List<Employee> SearchByName(string name)
        {
            var result = new List<Employee>();
            foreach (var item in Employees)
            {
                if ((item.FirstName + " " + item.LastName).ToLower().Contains(name))
                {
                    result.Add(item);
                }
            }
            return result;
        }

        public void PrintListEmployee(List<Employee> employeesByName)
        {
            
            employeesByName.ForEach(x => System.Console.WriteLine(x.ToString() + " " + x.GetType()));
        }

        public List<Employee> SearchByType(string type)
        {
            var result = new List<Employee>();

            if (type == "Hourly")
            {
                foreach (var item in HourlyEmployees)
                {
                    result.Add(item);
                }
            }

            if (type == "Salaried")
            {
                foreach (var item in SalariedEmployees)
                {
                    result.Add(item);
                }
            }
            return result;
        }

        

    }
}
