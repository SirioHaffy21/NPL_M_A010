﻿using NPL.M.A007_HaNS6.Models;
using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace NPL.M.A007_HaNS6
{
    internal class Program
    {
        public static EmployeeManagement management = new EmployeeManagement();
        private static void Main(string[] args)
        {
            MainMenu();
        }

        private static void MainMenu()
        {
            int selectMenu = 0;

            do
            {
                Console.WriteLine("Please select the admin area you require: ");
                Console.WriteLine("1. Import Employee. ");
                Console.WriteLine("2. Display Employee. ");
                Console.WriteLine("3. Search Employee. ");
                Console.WriteLine("4. Exit. ");
                selectMenu = int.Parse(Console.ReadLine());

                Console.WriteLine("");
                Console.Write($"Enter Menu Option Number: {selectMenu}");
                Console.WriteLine("");

                switch (selectMenu)
                {
                    case 1:
                        ImportEmployeeMenu();
                        break;
                    case 2:
                        DisplayAllEmployee();
                        break;
                    case 3:
                        MenuSearch();
                        break;
                    case 4:
                        Environment.Exit(0);
                        break;
                    default:
                        break;
                }
            } while (selectMenu != 1 || selectMenu != 2 || selectMenu != 3 || selectMenu != 4);
        }

        private static void MenuSearch()
        {
            int selectedSearchMenu = 0;

            do
            {
                Console.WriteLine("======== Search Employee ========");
                Console.WriteLine("1. By Employee Type");
                Console.WriteLine("2. By Employee Name");
                Console.WriteLine("3. Main Menu");
                Console.Write("Enter Menu Option Number: ");
                selectedSearchMenu = Convert.ToInt32(Console.ReadLine());

                switch (selectedSearchMenu)
                {
                    case 1:
                        SearchByTypeMenu();
                        break;
                    case 2:
                        Console.WriteLine("Please Input name:");
                        string name = Console.ReadLine();
                        var employeesByName = management.SearchByName(name);
                        management.PrintListEmployee(employeesByName);
                        break;
                    case 3:
                        MainMenu();
                        break;
                }
            } while (selectedSearchMenu != 1 || selectedSearchMenu != 2 || selectedSearchMenu != 3);
        }

        private static void SearchByTypeMenu()
        {
            int selectedSearchByTypeMenu = 0;

            do
            {
                Console.WriteLine("======== Search Employee ========");
                Console.WriteLine("1. Hourly");
                Console.WriteLine("2. Salaried");
                Console.WriteLine("3. Search Menu");
                Console.Write("Enter Menu Option Number: ");
                selectedSearchByTypeMenu = Convert.ToInt32(Console.ReadLine());

                switch (selectedSearchByTypeMenu)
                {
                    case 1:
                        var employeesByHourlyType = management.SearchByType("Hourly");
                        management.PrintListEmployee(employeesByHourlyType);
                        break;
                    case 2:
                        var employeesBySalariedType = management.SearchByType("Salaried");
                        management.PrintListEmployee(employeesBySalariedType);
                        break;
                    case 3:
                        MenuSearch();
                        break;
                }
            } while (selectedSearchByTypeMenu != 1 || selectedSearchByTypeMenu != 2 || selectedSearchByTypeMenu != 3);
        }

        private static void DisplayAllEmployee()
        {
            management.DisplayAll();
        }

        private static void ImportEmployeeMenu()
        {
            int selectedImportMenu = 0;

            do
            {
                Console.WriteLine("======== Import Employee ========");
                Console.WriteLine("1. Salaried Employee.");
                Console.WriteLine("2. Hourly Employee");
                Console.WriteLine("3. Main menu");

                selectedImportMenu = int.Parse(Console.ReadLine());

                Console.WriteLine("");
                Console.Write($"Enter Menu Option Number: {selectedImportMenu}");
                Console.WriteLine("");

                switch (selectedImportMenu)
                {
                    case 1:
                        var salariedEmploypee = InputBaseInformation();
                        CreateSalariedEmployee(salariedEmploypee);
                        break;
                    case 2:
                        var hourlyEmploypee = InputBaseInformation();
                        CreateHourlyEmployee(hourlyEmploypee);
                        break;

                    case 3:
                        MainMenu();
                        break;
                    default:
                        break;
                }
            } while (selectedImportMenu != 1 || selectedImportMenu != 2 || selectedImportMenu != 3);
        }

        private static void CreateHourlyEmployee(Tuple<string, string, string, DateTime, string, string> employee)
        {
            Console.WriteLine("Please Input wage:");
            double wage = double.Parse(Console.ReadLine());

            Console.WriteLine("Please Input workingHour:");
            double workingHour = double.Parse(Console.ReadLine());

            HourlyEmployee hourlyEmployee = new HourlyEmployee(employee.Item1, employee.Item2, employee.Item3,
                employee.Item4, employee.Item5, employee.Item6, wage, workingHour);

            management.Add(hourlyEmployee);
            management.AddHourly(hourlyEmployee);
        }

        private static void CreateSalariedEmployee(Tuple<string, string, string, DateTime, string, string> employee)
        {
            Console.WriteLine("Please Input commission rate:");
            double commissionRate = double.Parse(Console.ReadLine());


            Console.WriteLine("Please Input gross sales:");
            double grossSales = double.Parse(Console.ReadLine());

            Console.WriteLine("Please Input basic salary:");
            double basicSalary = double.Parse(Console.ReadLine());

            SalariedEmployee salariedEmployee = new SalariedEmployee(employee.Item1, employee.Item2, employee.Item3,
                employee.Item4, employee.Item5, employee.Item6, commissionRate, grossSales, basicSalary);

            management.Add(salariedEmployee);
            management.AddSalary(salariedEmployee);
        }

        private static Tuple<string, string, string, DateTime, string, string> InputBaseInformation()
        {
            Console.WriteLine("Please Input SSN:");
            string ssn = Console.ReadLine();


            Console.WriteLine("Please Input First Name:");
            string firstName = Console.ReadLine();

            Console.WriteLine("Please Input Last Name:");
            string lastName = Console.ReadLine();

            DateTime birthDate;
            string rawBirthDate = string.Empty;
            do
            {
                Console.WriteLine("Please Input birth date:");
                rawBirthDate = Console.ReadLine();

            } while (!DateTime.TryParseExact(rawBirthDate, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out birthDate));

            string phone = string.Empty;
            while (CheckedPhone(phone) != true)
            {
                Console.WriteLine("Please Input phone:");
                phone = Console.ReadLine();
            }

            string email = string.Empty;
            while (CheckedEmail(email) != true)
            {
                Console.WriteLine("Please Input email:");
                email = Console.ReadLine();
            }
            

            return new Tuple<string, string, string, DateTime, string, string>(ssn, firstName, lastName, birthDate, phone, email);
        }

        private static bool CheckedEmail(string email)
        {
            // Khai bao
            string characterEmail = @"[a-zA-Z0-9._]+@([a-z].)";

            // Call regex
            Regex regex = new Regex(characterEmail);


            // match regex
            Match match = regex.Match(email);

            // check
            if (match.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private static bool CheckedDate(string date)
        {
            // Khai bao
            string characterEmail = @"\d+\/\d+\/\d+";

            // Call regex
            Regex regex = new Regex(characterEmail);


            // match regex
            Match match = regex.Match(date);

            // check
            if (match.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private static bool CheckedPhone(string phone)
        {
            // Khai bao
            string characterPhone = @"[0-9]{10}";

            // Call regex
            Regex regex = new Regex(characterPhone);


            // match regex
            Match match = regex.Match(phone);

            // check
            if (match.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
