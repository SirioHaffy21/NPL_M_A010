﻿namespace NPL.M.A007_HaNS6.Models
{
    public enum EmployeeType
    {
        Salaried,
        Hourly
    }
}
