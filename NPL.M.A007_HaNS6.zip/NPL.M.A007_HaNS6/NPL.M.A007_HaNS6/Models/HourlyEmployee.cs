﻿using System;

namespace NPL.M.A007_HaNS6.Models
{
    public class HourlyEmployee : Employee
    {
        public HourlyEmployee()
        {

        }

        public HourlyEmployee(string sSN, string firstName, string lastName, DateTime birthDate, string phone, string email, double wage, double workingHour)
            : base(sSN, firstName, lastName, birthDate, phone, email)
        {
            Wage = wage;
            WorkingHour = workingHour;
        }

        public double Wage { get; set; }

        public double WorkingHour { get; set; }

        public override string ToString()
        {
            return base.ToString() + string.Format("{0, 20}{1, 20}", Wage, WorkingHour);
        }
    }
}
