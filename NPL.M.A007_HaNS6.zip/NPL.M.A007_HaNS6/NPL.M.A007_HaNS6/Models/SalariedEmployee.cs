﻿using System;

namespace NPL.M.A007_HaNS6.Models
{
    public class SalariedEmployee : Employee
    {
        public SalariedEmployee()
        {

        }

        public SalariedEmployee(string sSN, string firstName, string lastName, DateTime birthDate, string phone, string email, double commissionRate, double grossSales, double basicSalary)
            : base(sSN, firstName, lastName, birthDate, phone, email)
        {
            CommissionRate = commissionRate;

            GrossSales = grossSales;

            BasicSalary = basicSalary;
        }

        public double CommissionRate { get; set; }

        public double GrossSales { get; set; }

        public double BasicSalary { get; set; }

        public override string ToString()
        {
            return base.ToString() + string.Format("{0, 20}{1, 20}{2, 20}", CommissionRate, GrossSales, BasicSalary);
        }
    }
}
