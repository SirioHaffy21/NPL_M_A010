﻿using System;

namespace NPL.M.A007_HaNS6.Models
{
    public class Employee
    {
        public Employee()
        {

        }

        public Employee(string sSN, string firstName, string lastName)
        {
            SSN = sSN;
            FirstName = firstName;
            LastName = lastName;
        }

        public Employee(string sSN, string firstName, string lastName, DateTime birthDate, string phone, string email)
        {
            SSN = sSN;
            FirstName = firstName;
            LastName = lastName;
            BirthDate = birthDate;
            Phone = phone;
            Email = email;
        }

        public string SSN { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime BirthDate { get; set; }

        public string Phone { get; set; }

        public string Email { get; set; }

        public int CompareTo(Employee other)
        {
            return this.FirstName.CompareTo(other.FirstName);
        }

        public virtual new string ToString()
        {
            return String.Format("{0, -20}{1, 20}{2, 20}{3, 20}{4, 20}{5, 20}", SSN, FirstName, LastName, BirthDate, Phone, Email);
        }
    }

}
